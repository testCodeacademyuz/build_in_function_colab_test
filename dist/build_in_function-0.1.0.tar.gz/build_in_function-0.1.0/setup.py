from setuptools import setup

setup(
   name='build_in_function',
   version='0.1.0',
   packages=['build_in_function'],
   description='This is Built-in Function Test',
   install_requires=[
       "requests",
   ]
)